import React from "react"



export default function Article(){


    return(

<div className="w-fit h-fit  mb-4 ">
<h1 className=" lg:text-3xl font-semibold leading-tight pl-3 pt-3 ">
  Turkey's Tradegy
</h1>
<hr className="mt-6  border-gray-300 border-3"></hr>
<div className="mt-2 ml-2 text-sm flex"> 
<p className=" text-slate-500">Zarrar kuhro</p>
<p className="text-slate-500 mx-2">|</p>
<p className=""> Published February 13, 2023
</p>
</div>
<div className=" ">
  <div className="mx-96 my-64">

  <img src="./images.jpeg" className="-ml- w-72 h-72 inline-block "/>
  </div>
</div>


</div>


     


    
    )
}